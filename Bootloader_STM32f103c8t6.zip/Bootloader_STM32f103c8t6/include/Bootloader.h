/*
 * Bootloader.h
 *
 *  Created on: May 24, 2020
 *      Author: Mohamed Nafea
 */


/*Boot-loader application functions*/
extern void bootloader_voidUARTReadData (void);
extern void bootloader_voidJumpToUserApp(void);

