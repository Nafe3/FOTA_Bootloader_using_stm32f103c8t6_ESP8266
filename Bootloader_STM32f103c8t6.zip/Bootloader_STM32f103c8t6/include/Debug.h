/*
 * Debug.h
 *
 *  Created on: May 24, 2020
 *      Author: Mohamed Nafea
 */

#ifndef DEBUG_H_
#define DEBUG_H_

u16 printmsg1(const char* format, ...);
u16 printmsg2(const char* format, ...);
u16 printmsg3(const char* format, ...);



#endif /* DEBUG_H_ */
